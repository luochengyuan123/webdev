#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Created on 2017/04/28
@author: oliver
users模块的url配置。
"""

from django.conf.urls import patterns


