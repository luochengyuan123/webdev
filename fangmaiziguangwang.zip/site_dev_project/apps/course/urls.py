#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Created on 2017/04/28
@author: oliver
course模块的url配置。
"""

from django.conf.urls import url
# from .views import *
#
# urlpatterns = [
#     url(r'^careercourse/$', careercourse, name='careercourse'),
# ]
