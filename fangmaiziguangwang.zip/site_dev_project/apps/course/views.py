#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Created on 2017/05/03
@author: oliver
Course模块View业务处理。
"""

from django.shortcuts import render

# Create your views here.
# from site_dev_project.apps.common.models import *
#
#
# def careercourse(request):
#     careercourse_list = CareerCourse.objects.all()

    # return render(request, 'course/wheat.html', locals())